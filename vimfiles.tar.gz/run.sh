#!/bin/bash

echo "Init joerc"

echo "Checking user"
me=$(whoami)
if [ "$me" != "joe" ]; then
	echo "User is not joe"
	/bin/bash
	exit
fi
echo "User is joe"

echo "Checking if joerc is installed"
if [ -e /home/joe/.vim/joerc ]; then
	echo "Running joerc"
	/bin/bash
	exit
fi

echo "Making sure home directory exists"
sudo mkdir -p /home/joe/.vim
sudo chown -R joe:joe /home/joe

echo "Configuring joerc"
which git > /dev/null 2>&1
if [ $? != 0 ]; then
	ping -c 1 -W 1 8.8.8.8 > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "Installing git"
		if [ -f /etc/redhat-release ]; then
			sudo yum -y install git
		else
			sudo apt-get install git
		fi
	else
		echo "Could not run joerc"
		/bin/bash
		exit 1
	fi
fi

which screen > /dev/null 2>&1
if [ $? != 0 ]; then
	ping -c 1 -W 1 8.8.8.8 > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "Installing screen"
		if [ -f /etc/redhat-release ]; then
			sudo yum -y install screen
		else
			sudo apt-get install screen
		fi
	else
		echo "Could not run joerc"
		/bin/bash
		exit 1
	fi
fi

echo "Installing vim setup"
cd /tmp
git clone https://github.com/joedulin/vimsetup.git
cd vimsetup
./install.sh

/bin/bash
