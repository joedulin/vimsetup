#!/bin/bash

me=$(whoami)
if [ "$me" != "joe" ]; then
	exit
fi

if [ -f ~/.vim/joerc ]; then
	echo "Running joerc"
fi

echo "Configuring joerc"
which `git` > /dev/null 2>&1
if [ $? != 0 ]; then
	echo -e "GET http://google.com HTTP/1.0\n\n" | nc google.com 80 > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "Installing git"
		if [ -f /etc/redhat-release ]; then
			sudo yum -y install git
		else
			sudo apt-get install git
		fi
	else
		echo "Could not run joerc"
		exit 1
	fi
fi

which `screen` > /dev/null 2>&1
if [ $? != 0 ]; then
	echo -e "GET http://google.com HTTP/1.0\n\n" | nc google.com 80 > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo "Installing screen"
		if [ -f /etc/redhat-release ]; then
			sudo yum -y install screen
		else
			sudo apt-get install screen
		fi
	else
		echo "Could not run joerc"
		exit 1
	fi
fi

echo "Installing vim setup"
cd /tmp
git clone https://github.com/joedulin/vimsetup.git
cd vimsetup
./install.sh
