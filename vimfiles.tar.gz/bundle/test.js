var x = 'asdf';

for (var i=0;i<10;i++) {
	console.log(i);
}

function dosomething () {
	console.log('i did it');
}

var something_else = 'asdf';


