#!/bin/bash

/usr/bin/ssh -t "$@" "$(< ~/joerc/run.sh)"
