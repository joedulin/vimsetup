#!/bin/bash

/usr/bin/ssh "$@" "$(< ~/joerc/run.sh)"
